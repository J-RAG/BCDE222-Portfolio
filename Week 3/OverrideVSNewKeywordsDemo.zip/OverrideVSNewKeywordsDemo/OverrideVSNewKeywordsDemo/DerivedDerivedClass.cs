﻿using System;

namespace DemoOverrideVSNewKeywords
{
    class DerivedDerivedClass : DerivedClass
    {
        //public override void Method1()
        //{
        //    Console.WriteLine("DerivedDerived - override Method1");
        //}
    }
}
