namespace MultiFormDemo
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void btnFetch_Click(object sender, EventArgs e)
        {
            FormInput frmInput = new();
            if (frmInput.ShowDialog(this) == DialogResult.OK)
            {
                txtResult.Text = frmInput.fetchValueFromInputFrom();
            }
            frmInput.Dispose();
        }
    }
}