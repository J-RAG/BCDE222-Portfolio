﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            addName = new Button();
            label1 = new Label();
            listNames = new ListBox();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // addName
            // 
            addName.Location = new Point(164, 66);
            addName.Name = "addName";
            addName.Size = new Size(75, 23);
            addName.TabIndex = 0;
            addName.Text = "Add Name";
            addName.UseVisualStyleBackColor = true;
            addName.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 19);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 1;
            label1.Text = "Names";
            label1.Click += label1_Click;
            // 
            // listNames
            // 
            listNames.FormattingEnabled = true;
            listNames.ItemHeight = 15;
            listNames.Location = new Point(22, 37);
            listNames.Name = "listNames";
            listNames.Size = new Size(120, 94);
            listNames.TabIndex = 2;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(152, 37);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 3;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(264, 141);
            Controls.Add(textBox1);
            Controls.Add(listNames);
            Controls.Add(label1);
            Controls.Add(addName);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button addName;
        private Label label1;
        private ListBox listNames;
        private TextBox textBox1;
    }
}