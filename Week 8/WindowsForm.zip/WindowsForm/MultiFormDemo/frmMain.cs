namespace MultiFormDemo
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnFetch_Click(object sender, EventArgs e)
        {

        }
    }
}