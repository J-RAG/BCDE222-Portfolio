﻿namespace ChessMaze
{
    public enum Direction
    {
        Up,
        UpRight,
        Right,
        DownRight,
        Down,
        DownLeft,
        Left,
        UpLeft
            // Knight moves need to be considered
    }

}
