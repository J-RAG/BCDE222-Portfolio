﻿using System.Collections;
using System.Diagnostics;
using System.Numerics;
using System.Reflection.Emit;

namespace ChessMaze
{
    class Game : IGame
    {
        // is game finished 
        private bool gameState = false;

        // FEATURE 17 Must display level name
        public readonly string LevelName;

        // FEATURE 10: Must count total Number of Moves
        private int MoveCount { get; set; } = 0; // Number of Moves Made

        // FEATURE 14: Must have timer
        private Stopwatch gameTimer = new();

        // Level to generate the Board
         public Level TheLevel { get; private set; }

        // Game Board Which is initialised upon execution
        private char[,] Board { get; set; }

        // needed for Undo() and Move() method
        // Dynamic Array which stores all MoveLogs made by player
        private List<object> PlayerHistory = new();
        // MoveLogs (Board, Player's Position)
        private MoveLog CurrMove;
        private MoveLog PrevMove;

        // Constructor
        public Game(Level theLevel, List<object> playerHistory)
        {
            TheLevel = theLevel;
            LevelName = theLevel.Name;
            Board = theLevel.Board;

            // Initialise Player History
            PlayerHistory = playerHistory;
            CurrMove = new(Board, new(0, 0)); // always last item in list
            PrevMove = new(Board, new(0, 0)); // second last
            PlayerHistory.Add(PrevMove);
            PlayerHistory.Add(CurrMove);
        }

        // Set Up starting Level
        // Presets The starting Board and Returns it as a string.
        public string SetUpLevel(Level level)
        {
            // Note: The Level is Hard Coded in
            // Setting Player
            level.AddPlayerOnBishop(0, 0);

            // Add Bishop(s)
            level.AddBishop(3, 0);
            level.AddBishop(2, 2);

            // Add Rook(s) 
            level.AddRook(0, 3);
            level.AddRook(2, 1);
            level.AddRook(1, 1);

            // Add Knight(s)
            //level.AddKnight(1, 1);

            // Add King (end Point)
            level.AddKing(3, 3);

            return ToBoardString(CurrMove.Board);
        }

        // Convert The Board to a String
        private static string ToBoardString(char[,] board)
        {
            // the board to convert

            string stringBoard = "";

            for (int i = 0; i < board.GetLength(0); i++)
            {
                // Set Row Coordinates on Board
                if (i != 0)
                {
                    // Coordinate 0 is skipped as it does not align with the format 
                    stringBoard += (i + " ");
                }

                // Go through Each Row
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    // Set Column Coordinates on Board
                    if (j == 0 && i == 0)
                    {
                        stringBoard += ("   ");

                        for (int k = 0; k < board.GetLength(1); k++)
                        {
                            stringBoard += (k + " "); // Add Column Coordinate values
                        }
                        stringBoard += ("\n" + i + " "); // Display Coordinate value: 0 in line with the grid
                    }

                    // Add Pieces
                    stringBoard += ("|" + board[i, j]);

                    // If Last Item on Row Add end Strip
                    if (j == board.GetLength(1) - 1)
                    {
                        stringBoard += ('|');
                    }
                }
                stringBoard += ("\n");
            }
            stringBoard += "\n"; // Add a Space for next print

            return stringBoard;
        }

        public void Move(Direction moveDirection)
        {
            // Use Try 
            // and catch ArgumentOutOfRangeException (indexing)
            // Apply it for invalid move feature or something.... 
            var playerPos = GetCurrPos();
            var playerPart = TheLevel.GetPartAtIndex(playerPos.Row, playerPos.Col);

            List<object> playerMoves = GetMoves(playerPart);

            // Check if Part can move that Direction
            if (playerMoves.Contains(moveDirection))
            {
                // Check the Move does not go Out of Bounds
                if (!MoveIsValid(moveDirection, playerPos))
                {
                    Console.WriteLine($"Cannot Move {moveDirection}.\nOut of Bounds\n");
                }
                // Check the location of the move is not an Empty Space
                else if (IsPlayerOnEmpty(moveDirection, playerPos))
                {
                    Console.WriteLine($"Cannot Move {moveDirection}\nCell is Empty\n");
                }
                // Move the player to Direction
                else
                {
                    Console.WriteLine("Prev Board before Move: ");
                    DisplayBoard(PrevMove);
                    Console.WriteLine("Prev Board In History: ");
                    DisplayBoard((MoveLog)PlayerHistory[^2]);



                    var prevPos = PrevMove.Pos;
                    playerPos = MovePlayer(moveDirection);
                    UpdateBoard(playerPos, prevPos, playerPart);
                    UpdateHistory(playerPos);

                    // Display Updated Board
                    Console.WriteLine("Prev Board After Move: ");
                    DisplayBoard(PrevMove);
                    Console.WriteLine("Prev Board In History: ");
                    DisplayBoard((MoveLog)PlayerHistory[^2]);
                    DisplayBoard(CurrMove);
                }
            }
            else
            {
                Console.WriteLine($"Invalid Move.\nPart does not move {moveDirection}\n");
            }   
        }

        // Increment MoveCount by 1, Update the CurrMove and PrevMove.
        // Add new Player's Position and Board State to MoveLog and
        // Add that to the PlayerHistory
        private void UpdateHistory(Coord playerPos)
        {
            MoveCount++;
            PlayerHistory.Add(CurrMove);
            PrevMove = (MoveLog)PlayerHistory[^2];
            
            
        }

        // Convert Previous Player Part back to a Normal Part on the Board
        // Convert the current Player's Position into a 'PlayerOn' Part
        private void UpdateBoard(Coord newPos, Coord prevPos, Part prevPart) 
        {
            // Create a Clone Board to use as a previous Board
            // This is to bypass Object referencing
            CloneBoard orig = new CloneBoard { ClBoard = Board };
            CloneBoard cloneBoard = (CloneBoard)orig.Clone();
            var prevBoard = cloneBoard.ClBoard;

            // This is the new Part the Player is
            var partToConvert = TheLevel.GetPartAtIndex(newPos.Row, newPos.Col);
            
            // Convert That Part into a 'PlayerOn' Part
            switch (partToConvert)
            {
                case Part.King:
                    Board[newPos.Row, newPos.Col] = (char)Part.PlayerOnKing;
                    break;
                case Part.Rook:
                    Board[newPos.Row, newPos.Col] = (char)Part.PlayerOnRook;
                    break;
                case Part.Bishop:
                    Board[newPos.Row, newPos.Col] = (char)Part.PlayerOnBishop;
                    break;
                case Part.Knight:
                    Board[newPos.Row, newPos.Col] = (char)Part.PlayerOnKnight;
                    break;
            }

            // Convert Previous Part to a Normal Part
            switch (prevPart)
            {
                case Part.PlayerOnKing:
                    Board[prevPos.Row, prevPos.Col] = (char)Part.King;
                    break;
                case Part.PlayerOnRook:
                    Board[prevPos.Row, prevPos.Col] = (char)Part.Rook;
                    break;
                case Part.PlayerOnBishop:
                    Board[prevPos.Row, prevPos.Col] = (char)Part.Bishop;
                    break;
                case Part.PlayerOnKnight:
                    Board[prevPos.Row, prevPos.Col] = (char)Part.Knight;
                    break;
            }

            // Add Board to the MoveLog
            CurrMove = new(Board, newPos);
            PrevMove = new(prevBoard, prevPos);
        }

        // Move Player to square based on the Direction.
        // Returns the New Coordinates Where the player
        // moved.
        private Coord MovePlayer(Direction move)
        {
            /*          
                Declared as integers rather than the object
                This is to avoid declaring as an Object
                reference otherwise the variable will be
                updating CurrMove aswell
            */
            int newRow = CurrMove.Pos.Row;
            int newCol = CurrMove.Pos.Col;

            switch (move)
            {
                case Direction.Up:
                    newRow -= 1;
                    break;
                case Direction.Right:
                    newCol += 1;
                    break;
                case Direction.Left:
                    newCol -= 1;
                    break;
                case Direction.Down:
                    newRow += 1;
                    break;
                case Direction.UpRight:
                    newRow -= 1;
                    newCol += 1;
                    break;
                case Direction.DownRight:
                    newRow += 1;
                    newCol += 1;
                    break;
                case Direction.DownLeft:
                    newRow += 1;
                    newCol -= 1;
                    break;
                case Direction.UpLeft:
                    newRow -= 1;
                    newCol -= 1;
                    break;
            }

            return new(newRow, newCol);

        }

        // Check the Location of the Move is an Empty Part
        // Returns True if the Part is "Empty"
        private bool IsPlayerOnEmpty(Direction move, Coord playerPos)
        {
            var checkPos = playerPos;

            // Postion to check is based on MoveDirection
            switch (move)
            {
                case Direction.Up:
                    checkPos.Row -= 1;
                    break;
                case Direction.Right:
                    checkPos.Col += 1;
                    break;
                case Direction.Left:
                    checkPos.Col -= 1;
                    break;
                case Direction.Down:
                    checkPos.Row += 1;
                    break;
                case Direction.UpRight:
                    checkPos.Row -= 1;
                    checkPos.Col += 1;
                    break;
                case Direction.DownRight:
                    checkPos.Row += 1;
                    checkPos.Col += 1;
                    break;
                case Direction.DownLeft:
                    checkPos.Row += 1;
                    checkPos.Col -= 1;
                    break;
                case Direction.UpLeft:
                    checkPos.Row -= 1;
                    checkPos.Col -= 1;
                    break;
            }
            return (Part)Board[checkPos.Row, checkPos.Col] == Part.Empty;
        }

        // Return if move is Valid 
        private bool MoveIsValid(Direction move, Coord pos)
        {
            bool valid = false;
            var colLimit = Board.GetLength(1);
            var rowLimit = Board.GetLength(0);

            // Check what move is being Validated
            switch (move)
            {
                case Direction.Up:
                    valid = Moves.UpCheck(pos.Row);
                    break;
                case Direction.Right:
                    valid = Moves.RightCheck(pos.Col, colLimit);
                    break;
                case Direction.Left:
                    valid = Moves.LeftCheck(pos.Col);
                    break;
                case Direction.Down:
                    valid = Moves.DownCheck(pos.Row, rowLimit);
                    break;
                case Direction.UpRight:
                    valid = Moves.UpRightCheck(pos, colLimit);
                    break;
                case Direction.DownRight:
                    valid = Moves.DownRightCheck(pos, rowLimit, colLimit);
                    break;
                case Direction.DownLeft:
                    valid = Moves.DownLeftCheck(pos, rowLimit);
                    break;
                case Direction.UpLeft:
                    valid = Moves.UpLeftCheck(pos);
                    break;
            }

            return valid;
        }

        private static List<object> GetMoves(Part part)
        {
            List<object> moves = new();
            switch (part)
            {
                case Part.PlayerOnBishop:
                    moves =  Moves.GetBishopMoves();
                    break; 

                case Part.PlayerOnRook:
                    moves = Moves.GetRookMoves();
                    break;
            }
            return moves;
        }

        // FEATURE 12: Must have a reset button
        public void Restart()
        {
            // Reset Timer
            StopTimer();
            gameTimer = new();

            Console.Clear();
            Console.WriteLine("\n>>>RESTARTING LEVEL>>>");

            // Reset Move Count
            MoveCount = 0;

            // Turn Back to an Empty Board
            TheLevel.CreateLevel(TheLevel.Width, TheLevel.Height);
            Board = TheLevel.Board;

            // Reload Level 
            Load(SetUpLevel(TheLevel));

            // Reset Move History
            PlayerHistory = new();
            CurrMove = new(Board, new(0, 0));
            PrevMove = new(Board, new(0, 0));
            PlayerHistory.Add(PrevMove);
            PlayerHistory.Add(CurrMove);

            
           

        }

        // FEATURE 13: Must have undo button
        public void Undo()
        {
            // Cannot Undo as you are at the beginning
            if (MoveCount == 0)
            {
                Console.WriteLine("\nCannot Undo: You are at the start");
                GetMoveCount();
            }
            else
            {
                MoveCount--; // decrement Num Moves

                CurrMove = (MoveLog)PlayerHistory[^2];
                // Delete Latest Action from player history
                PlayerHistory.RemoveAt(PlayerHistory.Count - 1);
                PrevMove = (MoveLog)PlayerHistory[^2];

                // Update Board
                Board = CurrMove.Board;
                // Display Previous Board
                DisplayBoard(CurrMove);
            }
        }

        // Check if game has reached the goal
        public bool IsFinished()
        {
            // If we reached the goal the game should end
            if (TheLevel.GetPartAtIndex(CurrMove.Pos.Row, CurrMove.Pos.Col) == Part.PlayerOnKing)
            {
                gameState = true;
            }
            return gameState;
        }

        // FEATURE 1: Must have a game board with correct co-ordinates
        // This Will Generate the hard coded Level
        public void Load(string newLevel)
        {
            // Iniitalise Timer
            StartTimer();
            Console.WriteLine();
            Console.WriteLine(LevelName);
            Console.WriteLine(newLevel);
        }

        // FEATURE 14: Must have timer
        public void StartTimer()
        {
            gameTimer.Start();
        }

        // FEATURE 15: Must show time taken to beat level 
        // Stops the Game timer and returns the time in
        // 00:00:00.000 format.
        public string StopTimer()
        {
            gameTimer.Stop();
            TimeSpan ts = gameTimer.Elapsed;
            string time = String.Format
                (
                "{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10
                );
            return time;
        }

        public void DisplayTimer()
        {
            Console.WriteLine($"\nGame Time: {StopTimer()}");
            StartTimer(); // Continue Timer
        }

        // Returns User Input
        public static string Action(string prompt)
        {
            Console.Write(prompt);
            return Console.ReadLine() ?? "";
        }

        // Takes User input and runs the request
        public void RunAction(string action)
        {
            switch (action.ToLower())
            {
                // Get Options
                case "h":
                    DisplayOptions();
                    break;

                // Empty Input
                case "":
                    Console.WriteLine("\nNo input made.");
                    Console.WriteLine();
                    break;

                // Restart Game
                case "r":
                    Restart();
                    break;

                // Get Timer
                case "t":
                    DisplayTimer();
                    break;

                // FEATURE 10: Must count total Number of Moves
                // Get Move Count
                case "c":
                    GetMoveCount();
                    break;

                // Display Board
                case "b":
                    DisplayBoard(CurrMove);
                    break;

                // Display Player Position and their "Part"  Type
                case "p":
                    DisplayCurrentPosition();
                    break;

                // Undo Player's Last Move
                case "u":
                    Undo();
                    break;

                // Exit out of Game 
                case "q":
                    break;

                // Display Moves
                case "m":
                    DisplayMoves();
                    break;

                // Move Actions:
                case "up":
                    Move(Direction.Up);
                    break;
                case "down":
                    Move(Direction.Down);
                    break;
                case "left":
                    Move(Direction.Left);
                    break;
                case "right":
                    Move(Direction.Right);
                    break;
                case "upright":
                    Move(Direction.UpRight);
                    break;
                case "downright":
                    Move(Direction.DownRight);
                    break;
                case "downleft":
                    Move(Direction.DownLeft);
                    break;
                case "upleft":
                    Move(Direction.UpLeft);
                    break;
            }

        }

        // Display Moves
        private static void DisplayMoves()
        {
            Console.WriteLine();
            Console.WriteLine(" Moves: ");
            Console.WriteLine(" Up");
            Console.WriteLine(" Down");
            Console.WriteLine(" Left");
            Console.WriteLine(" Right");
            Console.WriteLine(" UpRight - Diagonal Up-Right");
            Console.WriteLine(" DownRight - Diagonal Down-Right");
            Console.WriteLine(" DownLeft - Diagonal Down-Left");
            Console.WriteLine(" UpLeft - Diagonal Up-Left");
            Console.WriteLine();
        }

        // Display User Options 
        private static void DisplayOptions()
        {
            Console.WriteLine();
            Console.WriteLine(" Options: ");
            Console.WriteLine(" r - Restart Level.");
            Console.WriteLine(" t - Get game time.");
            Console.WriteLine(" c - Get move count.");
            Console.WriteLine(" m - Display Moves.");
            Console.WriteLine(" p - Player Position");
            Console.WriteLine(" b - Display Board.");
            Console.WriteLine(" u - Undo last Move.");
            Console.WriteLine(" q - Exit Game.");
            Console.WriteLine();
        }

        // End Game Sequence
        public void End()
        {
            // User has Quit the Game
            if (!gameState)
            {
                Console.WriteLine("Gameover you Lose...");

            }
            else
            {
                // FEATURE 15: Must show time taken to beat level 
                // Game was Completed
                Console.WriteLine("Congrats!");
                Console.WriteLine($"Game Finished at {StopTimer()}");
            }

            Console.WriteLine();
            Console.WriteLine("Press any key to Exit");
            Console.ReadKey();
        }

        // FEATURE 10: Must count total Number of Moves
        // Display Move Count
        public int GetMoveCount()
        {
            if (MoveCount != 1)
            {
                Console.WriteLine($"\nYou have made {MoveCount} moves.");
            }
            else
            {
                Console.WriteLine($"\nYou have made {MoveCount} move");
            }
            return MoveCount;
        }

        // FEATURE 11: Must highlight current selected piece
        // Return The Current Posistion of Player.
        private Coord GetCurrPos()
        {
            return new(CurrMove.Pos.Row, CurrMove.Pos.Col); 
        }

        // Diplay Coordinates of Player and What Chess Piece they are
        private void DisplayCurrentPosition()
        {
            Console.WriteLine($"\nPlayer Positioned at ({CurrMove.Pos.Row}, {CurrMove.Pos.Col})");
            Console.WriteLine($"Player is a {TheLevel.GetPartAtIndex(CurrMove.Pos.Row, CurrMove.Pos.Col)}");
        }

        // Display Game Board
        private void DisplayBoard(MoveLog log) 
        {
            var stringBoard = ToBoardString(log.Board);
            Console.WriteLine();
            Console.WriteLine(LevelName);
            Console.WriteLine(stringBoard);
        }
    }
}
