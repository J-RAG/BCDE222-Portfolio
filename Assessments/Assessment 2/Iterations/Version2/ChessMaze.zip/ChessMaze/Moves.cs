﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ChessMaze
{
    class Moves
    {

        public static List<object> GetRookMoves()
        {
            List<object> moves = new()
            {
                Direction.Up,
                Direction.Right,
                Direction.Down,
                Direction.Left
            };

            return moves;
        }

        public static List<object> GetBishopMoves()
        {
            List<object> moves = new()
            {
                Direction.UpRight,
                Direction.DownRight,
                Direction.DownLeft,
                Direction.UpLeft
            };
            return moves;
        }


        // Move Validity
        // Directional Checks
        public static bool UpCheck(int rowPos)
        { 
            return rowPos - 1 >= 0;
        }
        public static bool DownCheck(int rowPos, int rowLimit)
        {
            return rowPos + 1 < rowLimit;
        }
        public static bool LeftCheck(int colPos)
        {
            return colPos - 1 >= 0;
        }
        public static bool RightCheck(int colPos, int colLimit)
        {
            return colPos - 1 < colLimit;
        }

        // Diagonal checks
        public static bool UpRightCheck(Coord pos, int colLimit)
        {
            return pos.Row - 1 >= 0 && pos.Col + 1 < colLimit;
        }
        public static bool UpLeftCheck(Coord pos)
        {
            return pos.Row - 1 >= 0 && pos.Col - 1 >= 0;
        }
        public static bool DownRightCheck(Coord pos, int rowLimit, int colLimit)
        {
            return pos.Row + 1 < rowLimit && pos.Col + 1 <= colLimit ;
        }
        public static bool DownLeftCheck(Coord pos,int rowLimit)
        {
            return pos.Row + 1 < rowLimit && pos.Col - 1 >= 0;
        }

        // Move the player







    }
}
