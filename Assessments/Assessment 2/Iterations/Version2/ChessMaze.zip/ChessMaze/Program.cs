﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ChessMaze
{
    class Program
    {
        static readonly Level _myLevel = new("Test Level", 4, 4);
        // List<object> is The MoveHistory (a,b)
        // a = Board,  b = Player Position 
        static readonly Game _game = new(_myLevel, new List<object>()); 

        static void Main(string[] args)
        {

            // Load Level
            _game.Load(_game.SetUpLevel(_game.TheLevel));

            // Start the Game
            while (!_game.IsFinished())
            {
                var action = Game.Action("Please input your next move ('h' for options): ");
                _game.RunAction(action);
                if (action.ToLower() == "q")
                { 
                    break; // Quit Game Option
                }
            }

            _game.End();
        }
    }

}