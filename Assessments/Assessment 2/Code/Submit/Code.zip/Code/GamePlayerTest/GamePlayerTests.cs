using System.Security.Cryptography.X509Certificates;
using System;
using System.Timers;
using System.Threading;

namespace GamePlayerTest
{
    [TestClass]
    public class GameBoardTests
    {

        [TestMethod]
        public void Feature1_GameBoardIsCreated_ExpectsReturnOfCharArray()
        {
            // Set
            Level testLevel = new("Test Level", 3, 3);
            testLevel.CreateLevel(testLevel.Width, testLevel.Height);
            var expectedBoard = testLevel.Board;

            // Act
            Game game = new();
            game.Load("___\n___\n___");
            var resultBoard = game.Board;

            // Assert
            CollectionAssert.AreEqual(expectedBoard, resultBoard);
        }

        [TestMethod]
        public void Feature1_LevelBoardIsCreated_ExpectsReturnOfCharArray()
        {
            // Set
            var expectedBoard = new char[,]
                {
                    {'_','_','_'},
                    {'_','_','_'},
                    {'_','_','_'}
                };

            // Act
            Game game = new();
            game.Load("___\n___\n___");
            var resultBoard = game.Board;

            // Assert
            CollectionAssert.AreEqual(expectedBoard, resultBoard);
        }

    }

    [TestClass]
    public class GameMoveSetTests
    {

        [TestMethod]
        public void Feature2_RookMoves_ExpectReturnRookSet()
        {
            // Set
            Direction[] expectedMoveSet =
                {
                    Direction.Up,
                    Direction.Right,
                    Direction.Down,
                    Direction.Left
                };

            // Act
            var resultSet = Coord.GetRookMoves();

            // Assert
            CollectionAssert.AreEqual(expectedMoveSet, resultSet);
        }

        [TestMethod]
        public void Feature2_GetMoves_ExpectReturnRookSet()
        {
            // Set
            Direction[] expectedMoveSet =
                {
                    Direction.Up,
                    Direction.Right,
                    Direction.Down,
                    Direction.Left
                };

            // Act
            var resultSet = Coord.GetMoves(Part.PlayerOnRook);

            // Assert
            CollectionAssert.AreEqual(expectedMoveSet, resultSet);
        }

        [TestMethod]
        public void Feature3_KingMoves_ExpectReturnKingSet()
        {
            // Set
            Direction[] expectedMoveSet =
                {
                    Direction.Up,
                    Direction.Right,
                    Direction.Down,
                    Direction.Left,
                    Direction.UpRight,
                    Direction.DownRight,
                    Direction.DownLeft,
                    Direction.UpLeft
                };

            // Act
            var resultSet = Coord.GetKingMoves();

            // Assert
            CollectionAssert.AreEqual(expectedMoveSet, resultSet);
        }

        [TestMethod]
        public void Feature3_GetMoves_ExpectReturnKingSet()
        {
            // Set
            Direction[] expectedMoveSet =
                {
                    Direction.Up,
                    Direction.Right,
                    Direction.Down,
                    Direction.Left,
                    Direction.UpRight,
                    Direction.DownRight,
                    Direction.DownLeft,
                    Direction.UpLeft
                };

            // Act
            var resultSet = Coord.GetMoves(Part.PlayerOnKing);

            // Assert
            CollectionAssert.AreEqual(expectedMoveSet, resultSet);
        }

        [TestMethod]
        public void Feature4_QueenMoves_ExpectReturnQueenSet()
        {
            // Set
            Direction[] expectedMoveSet =
                {
                    Direction.Up,
                    Direction.Right,
                    Direction.Down,
                    Direction.Left,
                    Direction.UpRight,
                    Direction.DownRight,
                    Direction.DownLeft,
                    Direction.UpLeft
                };

            // Act
            var resultSet = Coord.GetQueenMoves();

            // Assert
            CollectionAssert.AreEqual(expectedMoveSet, resultSet);
        }

        [TestMethod]
        public void Feature4_GetMoves_ExpectReturnQueenSet()
        {
            // Set
            Direction[] expectedMoveSet =
                {
                    Direction.Up,
                    Direction.Right,
                    Direction.Down,
                    Direction.Left,
                    Direction.UpRight,
                    Direction.DownRight,
                    Direction.DownLeft,
                    Direction.UpLeft
                };

            // Act
            var resultSet = Coord.GetMoves(Part.PlayerOnQueen);

            // Assert
            CollectionAssert.AreEqual(expectedMoveSet, resultSet);
        }

        [TestMethod]
        public void Feature5_KnightMoves_ExpectReturnKnightSet()
        {
            // Set
            Direction[] expectedMoveSet =
                {
                    Direction.UURight,
                    Direction.RRUp,
                    Direction.RRDown,
                    Direction.DDRight,
                    Direction.DDLeft,
                    Direction.LLDown,
                    Direction.LLUp,
                    Direction.UULeft
                };

            // Act
            var resultSet = Coord.GetKnightMoves();

            // Assert
            CollectionAssert.AreEqual(expectedMoveSet, resultSet);
        }

        [TestMethod]
        public void Feature5_MovesMoves_ExpectReturnKnightSet()
        {
            // Set
            Direction[] expectedMoveSet =
                {
                    Direction.UURight,
                    Direction.RRUp,
                    Direction.RRDown,
                    Direction.DDRight,
                    Direction.DDLeft,
                    Direction.LLDown,
                    Direction.LLUp,
                    Direction.UULeft
                };

            // Act
            var resultSet = Coord.GetMoves(Part.PlayerOnKnight);

            // Assert
            CollectionAssert.AreEqual(expectedMoveSet, resultSet);
        }

        [TestMethod]
        public void Feature6_BishopMoves_ExpectReturnBishopSet()
        {
            // Set
            Direction[] expectedMoveSet =
                {
                    Direction.UpRight,
                    Direction.DownRight,
                    Direction.DownLeft,
                    Direction.UpLeft
                };

            // Act
            var resultSet = Coord.GetBishopMoves();

            // Assert
            CollectionAssert.AreEqual(expectedMoveSet, resultSet);
        }

        [TestMethod]
        public void Feature6_GetMoves_ExpectReturnBishopSet()
        {
            // Set
            Direction[] expectedMoveSet =
                {
                    Direction.UpRight,
                    Direction.DownRight,
                    Direction.DownLeft,
                    Direction.UpLeft
                };

            // Act
            var resultSet = Coord.GetMoves(Part.PlayerOnBishop);

            // Assert
            CollectionAssert.AreEqual(expectedMoveSet, resultSet);
        }
    }

    [TestClass]
    public class GameMoveValidationTests
    {
        [TestMethod]
        public void Feature7_MoveInbounds_ExpectTrue()
        {
            // Set
            Game testGame = new();
            testGame.Load("r__\nB___\n___");

            // Act
            var result = Coord.MoveIsValid(Direction.Down, new(0, 0), testGame.Board.GetLength(1), testGame.Board.GetLength(0));

            // Assert
            Assert.IsTrue(result);

        }

        [TestMethod]
        public void Feature7_MoveOutOfBounds_ExpectFalse()
        {
            // Set
            Game testGame = new();

            // Act
            testGame.Load("r__\nB___\n___");
            var result = Coord.MoveIsValid(Direction.Up, new(0, 0), testGame.Board.GetLength(1), testGame.Board.GetLength(0));

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Feature8_MoveInSet_ExpectTrue()
        {
            // Set
            Game testGame = new();
            testGame.Load("r__\nB___\n___");
            var testDirection = Direction.Up;
            var rookMoveSet = Coord.GetRookMoves();

            // Act
            var result = rookMoveSet.Contains(testDirection);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Feature8_MoveNotInSet_ExpectFalse()
        {
            // Set
            Game testGame = new();
            testGame.Load("r__\nB___\n___");
            var testDirection = Direction.UpRight;
            var rookMoveSet = Coord.GetRookMoves();

            // Act
            var result = rookMoveSet.Contains(testDirection);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Feature9_SquareIsEmpty_ExpectTrue()
        {
            // Set 
            Game testGame = new();
            testGame.Load("r__\nB___\n___");
            var testDirection = Direction.Right;
            Coord startPos = new(0, 0);

            // Act
            var result = Coord.IsPlayerOnEmpty(testDirection, startPos, testGame.GameLevel);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Feature9_SquareIsNotEmpty_ExpectFalse()
        {
            // Set 
            Game testGame = new();
            testGame.Load("r__\nB___\n___");
            var testDirection = Direction.Down;
            Coord startPos = new(0, 0);

            // Act
            var result = Coord.IsPlayerOnEmpty(testDirection, startPos, testGame.GameLevel);

            // Assert
            Assert.IsFalse(result);
        }

    }

    [TestClass]
    public class GamePropertiesTest
    {
        // private static System.Timers.Timer testTimer;
        [TestMethod]
        public void Feature10_ZeroMoves_ExpectReturnMoveCount()
        {
            // Set
            var expectedcount = 0;

            // Act
            Game testGame = new();
            var resultCount = testGame.GetMoveCount();

            // Assert
            Assert.AreEqual(expectedcount, resultCount);
        }

        [TestMethod]
        public void Feature10_OneMove_ExpectReturnMoveCount()
        {
            // Set
            var expectedcount = 1;

            // Act
            Game testGame = new();
            testGame.Load("r__\nB___\n___");
            testGame.Move(Direction.Down);
            var resultCount = testGame.GetMoveCount();

            // Assert
            Assert.AreEqual(expectedcount, resultCount);
        }

        [TestMethod]
        public void Feature11_GetCurrPos_ExpectReturnPlayerPosition()
        {
            // Set
            Coord expectetCoordinates = new(0, 0);

            // Act
            Game testGame = new();
            testGame.Load("r__\nB___\n___");
            var resultCoordinates = testGame.GetCurrPos();

            // Assert
            Assert.AreEqual(expectetCoordinates.Col, resultCoordinates.Col);
            Assert.AreEqual(expectetCoordinates.Row, resultCoordinates.Row);
        }

        [TestMethod]
        public void Feature11_MoveThenGetPos_ExpectReturnPlayerPosition()
        {
            // Set
            Coord expectetCoordinates = new(1, 0);

            // Act
            Game testGame = new();
            testGame.Load("r__\nB___\n___");
            testGame.Move(Direction.Down);
            var resultCoordinates = testGame.GetCurrPos();

            // Assert
            Assert.AreEqual(expectetCoordinates.Col, resultCoordinates.Col);
            Assert.AreEqual(expectetCoordinates.Row, resultCoordinates.Row);

        }

        [TestMethod]
        public void Feature14_GameTimerIsRunnning_ReturnsTrue()
        {
            // Arrange
            Game testGame = new();

            // Act
            testGame.StartTimer();
            var result = testGame.GameTimer.IsRunning;

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Feature14_GameTimerNotRunning_WhenTimerIsStopped_ReturnFalse()
        {
            // Arrange
            Game testGame = new();

            // Act
            testGame.StartTimer();
            testGame.StopTimer();
            var result = testGame.GameTimer.IsRunning;

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Feature17_LevelName_ExpectReturnName()
        {
            // Arrange
            Level testLevel = new("Test Level", 3, 3);
            var expectedName = testLevel.Name;

            // Act
            Game testGame = new();
            testGame.Load("r__\nB___\n___");
            var resultName = testGame.GameLevel.Name; // NOTE: The level name is Hard-Coded in

            // Assert
            Assert.AreEqual(expectedName, resultName);
        }

        [TestMethod]
        public void Feature17_RestartLevel_GetName_ExpectReturnName()
        {
            // Arrange
            Level testLevel = new("Test Level", 3, 3);
            var expectedName = testLevel.Name;

            // Act
            Game testGame = new();
            testGame.Load();
            testGame.Restart();
            var resultName = testGame.GameLevel.Name;
            // Assert
            Assert.IsTrue(expectedName == resultName);
        }

    }

    [TestClass]
    public class GameActionTest
    {
        [TestMethod]
        public void Feature12_Restart_ExpectReturnSameGameBoard()
        {
            // Arrange
            var expectedBoard = new char[,]
                {
                    {'b','_','_','_'},
                    {'_','Q','N','_'},
                    {'_','B','R','_'},
                    {'B','_','R','K'}
                };

            // Act
            Game testGame = new();
            testGame.Load();
            testGame.Restart();
            var resultBoad = testGame.Board;
            // Assert
            CollectionAssert.AreEqual(expectedBoard, resultBoad);
        }

        [TestMethod]
        public void Feature12_Restart_ExpectReturnSameLevelBoard()
        {
            // Arrange
            var expectedBoard = new char[,]
                {
                    {'b','_','_','_'},
                    {'_','Q','N','_'},
                    {'_','B','R','_'},
                    {'B','_','R','K'}
                };

            // Act
            Game testGame = new();
            testGame.Load();
            testGame.Restart();
            var resultBoard = testGame.GameLevel.Board;
            // Assert
            CollectionAssert.AreEqual(expectedBoard, resultBoard);
        }

        [TestMethod]
        public void Feature13_UndoBaseCase_ExpectStatisticsToMatchResults()
        {
            // Arrange
            var expectedHistoryCount = 2;

            Coord expectedPlayerPos = new(0, 0);
            var expectedPlayerPart = Part.PlayerOnBishop;
            var expectedBoard = new char[,]

                {
                    {'b','_','_','_'},
                    {'_','Q','N','_'},
                    {'_','B','R','_'},
                    {'B','_','R','K'}
                };

            // Act
            Game testGame = new();
            testGame.Load();
            testGame.Move(Direction.DownRight);
            testGame.Undo();

            var resultHistoryCount = testGame.PlayerHistory.Count;
            var resultPlayerPos = testGame.GetCurrPos();
            var resultPlayerPart = testGame.GameLevel.GetPartAtIndex(resultPlayerPos.Row, resultPlayerPos.Col);
            var resultBoard = testGame.GameLevel.Board;

            // Assert
            Assert.AreEqual(expectedHistoryCount, resultHistoryCount);
            Assert.AreEqual(expectedPlayerPos.Col, resultPlayerPos.Col);
            Assert.AreEqual(expectedPlayerPos.Row, resultPlayerPos.Row);
            Assert.AreEqual(expectedPlayerPart, resultPlayerPart);
            CollectionAssert.AreEqual(expectedBoard, resultBoard);
        }

        [TestMethod]
        public void Feature13_Undo2Moves_ExpectStatisticsToMatchResults()
        {
            // Arrange
            var expectedHistoryCount = 2;

            Coord expectedPlayerPos = new(1, 1);
            var expectedPlayerPart = Part.PlayerOnQueen;
            var expectedBoard = new char[,]

                {
                    {'B','_','_','_'},
                    {'_','q','N','_'},
                    {'_','B','R','_'},
                    {'B','_','R','K'}
                };

            // Act
            Game testGame = new();
            testGame.Load();
            testGame.Move(Direction.DownRight);
            testGame.Move(Direction.Down);

            testGame.Undo();

            var resultHistoryCount = testGame.PlayerHistory.Count;
            var resultPlayerPos = testGame.GetCurrPos();
            var resultPlayerPart = testGame.GameLevel.GetPartAtIndex(resultPlayerPos.Row, resultPlayerPos.Col);
            var resultBoard = testGame.GameLevel.Board;

            // Assert
            Assert.AreEqual(expectedHistoryCount, resultHistoryCount);
            Assert.AreEqual(expectedPlayerPos.Col, resultPlayerPos.Col);
            Assert.AreEqual(expectedPlayerPos.Row, resultPlayerPos.Row);
            Assert.AreEqual(expectedPlayerPart, resultPlayerPart);
            CollectionAssert.AreEqual(expectedBoard, resultBoard);
        }

        [TestMethod]
        public void Feature13_2Undo3Moves_ExpectStatisticsToMatchResults()
        {
            // Arrange
            var expectedHistoryCount = 2;

            Coord expectedPlayerPos = new(1, 1);
            var expectedPlayerPart = Part.PlayerOnQueen;
            var expectedBoard = new char[,]

                {
                    {'B','_','_','_'},
                    {'_','q','N','_'},
                    {'_','B','R','_'},
                    {'B','_','R','K'}
                };

            // Act
            Game testGame = new();
            testGame.Load();
            testGame.Move(Direction.DownRight);
            testGame.Move(Direction.Down);
            testGame.Move(Direction.DownRight);

            testGame.Undo();
            testGame.Undo();

            var resultHistoryCount = testGame.PlayerHistory.Count;
            var resultPlayerPos = testGame.GetCurrPos();
            var resultPlayerPart = testGame.GameLevel.GetPartAtIndex(resultPlayerPos.Row, resultPlayerPos.Col);
            var resultBoard = testGame.GameLevel.Board;

            // Assert
            Assert.AreEqual(expectedHistoryCount, resultHistoryCount);
            Assert.AreEqual(expectedPlayerPos.Col, resultPlayerPos.Col);
            Assert.AreEqual(expectedPlayerPos.Row, resultPlayerPos.Row);
            Assert.AreEqual(expectedPlayerPart, resultPlayerPart);
            CollectionAssert.AreEqual(expectedBoard, resultBoard);
        }

        [TestMethod]
        public void Feature15_ReturnTimer_AsTypeString()
        {
            // Arrange
            Game testGame = new();
            testGame.Load();
            var result = testGame.StopTimer();

            Assert.IsInstanceOfType(result, typeof(string));
        }


        [TestMethod]
        public void Feature16_GameIsFinished_ExpectReturnTrue()
        {
            // Arrange
            Game testGame = new();
            testGame.Load();
            testGame.Move(Direction.DownRight);
            testGame.Move(Direction.DownRight);
            testGame.Move(Direction.Down);
            testGame.Move(Direction.Right);

            // Act
            var resultOutput = testGame.IsFinished();

            // Assert
            Assert.IsTrue(resultOutput);
        }

        [TestMethod]
        public void Feature16_GameIsNotFinished_ExpectReturnFalse()
        {
            // Arrange
            Game testGame = new();
            testGame.Load();
            testGame.Move(Direction.DownRight);
            testGame.Move(Direction.DownRight);
            testGame.Move(Direction.Down);

            // Act
            var resultOutput = testGame.IsFinished();

            // Assert
            Assert.IsFalse(resultOutput);
        }

    }

    [TestClass]
    public class GameConstructorTest
    {
        [TestMethod]
        public void GameHas_InitialProperties()
        {
            // Arrange
            List<Coord> expectedHistory = new()
            {
                new(0, 0),
                new(0, 0)
            };

            var expectedName = "Init";
            char[,] expectedBoard = { };


            // Act
            Game testGame = new();
            var resultHistory = testGame.PlayerHistory;
            var resultName = testGame.GameLevel.Name;
            var resultBoard = testGame.Board;

            // Assert
            Assert.AreEqual(expectedHistory[0].Row, resultHistory[0].Row);
            Assert.AreEqual(expectedHistory[0].Col, resultHistory[0].Col);
            Assert.AreEqual(expectedHistory[1].Row, resultHistory[1].Row);
            Assert.AreEqual(expectedHistory[1].Col, resultHistory[1].Col);

            Assert.AreEqual(expectedName, resultName);
            CollectionAssert.AreEqual(expectedBoard, resultBoard);

        }
    }



}