﻿namespace ChessMaze
{
    /* 
     * Coordinates used for positioning.
     * Contains Postioning Validity Checks for the Player.
     * Updates Position if Movement action is validated
     */
    public class Coord
    {
        public int Row { get; set; }
        public int Col { get; set; }

        public Coord(int row, int col)
        {
            Row = row;
            Col = col;
        }

        // Methods 
        // FEATURE 2: Must have movement for Rook
        public static Direction[] GetRookMoves()
        {
            Direction[] moves =
            {
                Direction.Up,
                Direction.Right,
                Direction.Down,
                Direction.Left
            };

            return moves;
        }

        // FEATURE 3: Must have movement for King
        public static Direction[] GetKingMoves()
        {
            return GetQueenMoves();
        }

        // FEATURE 4: Must have movement for Queen
        public static Direction[] GetQueenMoves()
        {
            Direction[] moves =
            {
                Direction.Up,
                Direction.Right,
                Direction.Down,
                Direction.Left,
                Direction.UpRight,
                Direction.DownRight,
                Direction.DownLeft,
                Direction.UpLeft
            };
            return moves;
        }

        // FEATURE 5: Must have movement for Knight
        public static Direction[] GetKnightMoves()
        {
            Direction[] moves =
            {
                Direction.UURight,
                Direction.RRUp,
                Direction.RRDown,
                Direction.DDRight,
                Direction.DDLeft,
                Direction.LLDown,
                Direction.LLUp,
                Direction.UULeft
            };
            return moves;
        }

        // FEATURE 6: Must have movement for Bishop
        public static Direction[] GetBishopMoves()
        {
            Direction[] moves =
            {
                Direction.UpRight,
                Direction.DownRight,
                Direction.DownLeft,
                Direction.UpLeft
            };
            return moves;
        }

        // FEATURE 8: Must have the ability to select pieces to move
        public static Direction[] GetMoves(Part part)
        {
            Direction[] moves = Array.Empty<Direction>();
            switch (part)
            {
                case Part.PlayerOnBishop:
                    moves = GetBishopMoves();
                    break;

                case Part.PlayerOnRook:
                    moves = GetRookMoves();
                    break;

                case Part.PlayerOnQueen:
                    moves = GetQueenMoves();
                    break;

                case Part.PlayerOnKing:
                    moves = GetKingMoves();
                    break;

                case Part.PlayerOnKnight:
                    moves = GetKnightMoves();
                    break;
            }
            return moves;
        }

        // FEATURE 7: Must be able to detect incorrect movement
        // Return if move is Valid 
        public static bool MoveIsValid(
            Direction move, 
            Coord pos, 
            int colLimit, 
            int rowLimit)
        {
            bool valid = false;

            // Check what move is being Validated
            switch (move)
            {
                case Direction.Up:
                    valid = UpCheck(pos.Row);
                    break;
                case Direction.Right:
                    valid = RightCheck(pos.Col, colLimit);
                    break;
                case Direction.Left:
                    valid = LeftCheck(pos.Col);
                    break;
                case Direction.Down:
                    valid = DownCheck(pos.Row, rowLimit);
                    break;
                case Direction.UpRight:
                    valid = UpRightCheck(pos, colLimit);
                    break;
                case Direction.DownRight:
                    valid = DownRightCheck(pos, rowLimit, colLimit);
                    break;
                case Direction.DownLeft:
                    valid = DownLeftCheck(pos, rowLimit);
                    break;
                case Direction.UpLeft:
                    valid = UpLeftCheck(pos);
                    break;

                // Knight Checks
                case Direction.UURight:
                    valid = UURightCheck(pos, colLimit);
                    break;
                case Direction.RRUp:
                    valid = RRUpCheck(pos, colLimit);
                    break;
                case Direction.RRDown:
                    valid = RRDownCheck(pos, rowLimit, colLimit);
                    break;
                case Direction.DDRight:
                    valid = DDRightCheck(pos, rowLimit, colLimit);
                    break;
                case Direction.DDLeft:
                    valid = DDLeftCheck(pos, rowLimit);
                    break;
                case Direction.LLDown:
                    valid = LLDownCheck(pos, rowLimit);
                    break;
                case Direction.LLUp:
                    valid = LLUpCheck(pos);
                    break;
                case Direction.UULeft:
                    valid = UULeftCheck(pos);
                    break;
            }

            return valid;
        }

        // Directional Checks
        private static bool UpCheck(int rowPos)
        {
            return rowPos - 1 >= 0;
        }
        private static bool DownCheck(int rowPos, int rowLimit)
        {
            return rowPos + 1 < rowLimit;
        }
        private static bool LeftCheck(int colPos)
        {
            return colPos - 1 >= 0;
        }
        private static bool RightCheck(int colPos, int colLimit)
        {
            return colPos - 1 < colLimit;
        }

        // Diagonal checks
        private static bool UpRightCheck(Coord pos, int colLimit)
        {
            return pos.Row - 1 >= 0 && pos.Col + 1 < colLimit;
        }
        private static bool UpLeftCheck(Coord pos)
        {
            return pos.Row - 1 >= 0 && pos.Col - 1 >= 0;
        }
        private static bool DownRightCheck(Coord pos, int rowLimit, int colLimit)
        {
            return pos.Row + 1 < rowLimit && pos.Col + 1 < colLimit;
        }
        private static bool DownLeftCheck(Coord pos, int rowLimit)
        {
            return pos.Row + 1 < rowLimit && pos.Col - 1 >= 0;
        }

        // Knight Move Checks
        private static bool UURightCheck(Coord pos, int colLimit)
        {
            return pos.Row - 2 >= 0 && pos.Col + 1 < colLimit;
        }
        private static bool RRUpCheck(Coord pos, int colLimit)
        {
            return pos.Row - 1 >= 0 && pos.Col + 2 < colLimit;
        }
        private static bool RRDownCheck(Coord pos, int rowLimit, int colLimit)
        {
            return pos.Row + 1 < rowLimit && pos.Col + 2 < colLimit;
        }
        private static bool DDRightCheck(Coord pos, int rowLimit, int colLimit)
        {
            return pos.Row + 2 < rowLimit && pos.Col + 1 < colLimit;
        }
        private static bool DDLeftCheck(Coord pos, int rowLimit)
        {
            return pos.Row + 2 < rowLimit && pos.Col - 1 >= 0;

        }
        private static bool LLDownCheck(Coord pos, int rowLimit)
        {
            return pos.Row + 1 < rowLimit && pos.Col - 2 >= 0;
        }
        private static bool LLUpCheck(Coord pos)
        {
            return pos.Row - 1 >= 0 && pos.Col - 2 >= 0;
        }
        private static bool UULeftCheck(Coord pos)
        {
            return pos.Row - 2 >= 0 && pos.Col - 1 >= 0;
        }

        // FEATURE 9: Must not accept movement to empty squares
        public static bool IsPlayerOnEmpty(Direction move, Coord playerPos, Level level)
        {
            /*          
                Declared as new Object to 
                avoid Object referencing
                
                var checkPos = playerPos; // X NO this will mess everything up
            */
            Coord checkPos = new(playerPos.Row, playerPos.Col); // Not really Good, Data redundancy 

            // Postion to check is based on MoveDirection
            switch (move)
            {
                case Direction.Up:
                    checkPos.Row -= 1;
                    break;
                case Direction.Right:
                    checkPos.Col += 1;
                    break;
                case Direction.Left:
                    checkPos.Col -= 1;
                    break;
                case Direction.Down:
                    checkPos.Row += 1;
                    break;
                case Direction.UpRight:
                    checkPos.Row -= 1;
                    checkPos.Col += 1;
                    break;
                case Direction.DownRight:
                    checkPos.Row += 1;
                    checkPos.Col += 1;
                    break;
                case Direction.DownLeft:
                    checkPos.Row += 1;
                    checkPos.Col -= 1;
                    break;
                case Direction.UpLeft:
                    checkPos.Row -= 1;
                    checkPos.Col -= 1;
                    break;

                // Knight Checks
                case Direction.UURight:
                    checkPos.Row -= 2;
                    checkPos.Col += 1;
                    break;
                case Direction.RRUp:
                    checkPos.Row -= 1;
                    checkPos.Col += 2;
                    break;
                case Direction.RRDown:
                    checkPos.Row += 1;
                    checkPos.Col += 2;
                    break;
                case Direction.DDRight:
                    checkPos.Row += 2;
                    checkPos.Col += 1;
                    break;
                case Direction.DDLeft:
                    checkPos.Row += 2;
                    checkPos.Col -= 1;
                    break;
                case Direction.LLDown:
                    checkPos.Row += 1;
                    checkPos.Col -= 2;
                    break;
                case Direction.LLUp:
                    checkPos.Row -= 1;
                    checkPos.Col -= 2;
                    break;
                case Direction.UULeft:
                    checkPos.Row -= 2;
                    checkPos.Col -= 1;
                    break;
            }
            return level.GetPartAtIndex(checkPos.Row, checkPos.Col) == Part.Empty;
        }

        public static Coord MovePlayer(Direction move, Coord playerPos)
        {
            /*          
                Declared as new Object to 
                avoid Object referencing
            */
            Coord newPos = new(playerPos.Row, playerPos.Col); // Not really Good, Data redundancy 

            switch (move)
            {
                case Direction.Up:
                    newPos.Row -= 1;
                    break;
                case Direction.Right:
                    newPos.Col += 1;
                    break;
                case Direction.Left:
                    newPos.Col -= 1;
                    break;
                case Direction.Down:
                    newPos.Row += 1;
                    break;
                case Direction.UpRight:
                    newPos.Row -= 1;
                    newPos.Col += 1;
                    break;
                case Direction.DownRight:
                    newPos.Row += 1;
                    newPos.Col += 1;
                    break;
                case Direction.DownLeft:
                    newPos.Row += 1;
                    newPos.Col -= 1;
                    break;
                case Direction.UpLeft:
                    newPos.Row -= 1;
                    newPos.Col -= 1;
                    break;

                // Knight Moves
                case Direction.UURight:
                    newPos.Row -= 2;
                    newPos.Col += 1;
                    break;
                case Direction.RRUp:
                    newPos.Row -= 1;
                    newPos.Col += 2;
                    break;
                case Direction.RRDown:
                    newPos.Row += 1;
                    newPos.Col += 2;
                    break;
                case Direction.DDRight:
                    newPos.Row += 2;
                    newPos.Col += 1;
                    break;
                case Direction.DDLeft:
                    newPos.Row += 2;
                    newPos.Col -= 1;
                    break;
                case Direction.LLDown:
                    newPos.Row += 1;
                    newPos.Col -= 2;
                    break;
                case Direction.LLUp:
                    newPos.Row -= 1;
                    newPos.Col -= 2;
                    break;
                case Direction.UULeft:
                    newPos.Row -= 2;
                    newPos.Col -= 1;
                    break;
            }

            return newPos;

        }
    }
}
