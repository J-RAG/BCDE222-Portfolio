﻿using System.ComponentModel;
using System.Runtime.InteropServices;

namespace ChessMaze
{
    /*
     * Game Level created for Game Player.
     * Used to Demostrate the Game player 
     * Functionality. 
     */

    public class Level
    {
        // Feature 17: Must display level name
        public string Name { get; set; }

        // Dimensions of the "board"
        public int Width { get; set; }
        public int Height { get; set; }

        public char[,] Board { get; set; }

        // Constructor
        public Level(string name, int width, int height)
        {
            Name = name;
            Width = width;
            Height = height;
            Board = new char[width, height];
        }

        // FEATURE 1: Must have a game board with correct co-ordinates
        // Creates The Chess Board, All squares will be declared "Empty"
        public void CreateLevel(int rowSize, int columnSize)
        {
            for (int row = 0; row < rowSize; row++)
            {
                for (int col = 0; col < columnSize; col++)
                {
                    // Create an "Empty" square
                    AddEmpty(row, col);
                }
            }
        }


        // Set Peices on Board
        public void AddEmpty(int row, int col)
        {
            Board[row, col] = (char)Part.Empty;
        }


        // FEATURE 11: Must highlight current selected piece
        // Return Part on Selected Square
        public Part GetPartAtIndex(int row, int col)
        {
            return (Part)Board[row, col];

        }

        public int GetLevelWidth()
        {
            return Width;
        }

        public int GetLevelHeight()
        {
            return Height;
        }
    }
}