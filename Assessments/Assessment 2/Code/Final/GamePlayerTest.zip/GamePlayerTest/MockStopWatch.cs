﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessMaze
{
    public class MockStopWatch : IStopwatch
    {
        private bool _isRunning;

        public void Start()
        {
            _isRunning = true;
        }

        public void Stop()
        {
            _isRunning = false;
        }

        public TimeSpan Elapsed { get; private set; }
        public bool IsRunning => _isRunning;
    }
}
