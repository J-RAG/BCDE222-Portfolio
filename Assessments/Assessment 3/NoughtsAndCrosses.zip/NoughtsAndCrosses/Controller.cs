﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NoughtsAndCrossesModel;
namespace NoughtsAndCrossesView
{
    class Controller
    {
        IGame game = new Game();
        public string Turn()
        {
            return $"Turn: {game.Turn()}";
        }
        public void AddMark(string row, string column, string mark)
        {
            game.AddMark(int.Parse(row), int.Parse(column), char.Parse(mark));
        }
        public string WhatsAt(string row, string column)
        {
            return game.WhatIsAt(int.Parse(row), int.Parse(column)).ToString();
        }
    }
}
