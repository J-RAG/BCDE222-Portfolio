﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NoughtsAndCrossesModel
{
    public class Game : IGame
    {
        int _turn = 0;
        char[,] board = new char[,] { {' ', ' ', ' ' },{ ' ', ' ', ' ' },{ ' ', ' ', ' ' } };

        public void AddMark(int row, int column, char mark)
        {
            board[row, column] = mark;
            _turn++;
        }

        public int Turn()
        {
            return _turn;
        }

        public char WhatIsAt(int row, int column)
        {
            return board[row, column];
        }
    }
}
