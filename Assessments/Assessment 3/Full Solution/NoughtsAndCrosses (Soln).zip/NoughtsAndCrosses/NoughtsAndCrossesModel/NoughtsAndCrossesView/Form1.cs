﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NoughtsAndCrossesView
{
    public partial class Form1 : Form
    {
        Controller controller = new Controller();
        public Form1()
        {
            InitializeComponent();
            lblTurn.Text = controller.Turn();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            controller.AddMark("0", "0", "X");
            controller.AddMark("0", "1", "0");
            controller.AddMark("0", "2", "X");
            controller.AddMark("1", "1", "O");
            controller.AddMark("1", "0", "X");
            controller.AddMark("1", "2", "X");
            controller.AddMark("2", "0", "0");
            controller.AddMark("2", "1", "X");
            controller.AddMark("2", "2", "0");

            /*
            btn00.Text = controller.WhatsAt("0", "0");
            btn01.Text = controller.WhatsAt("0", "1");
            btn02.Text = controller.WhatsAt("0", "2");
            */
            for (int row = 0; row <= 2; row++)
            {
                for (int column = 0; column <= 2; column++)
                {
                    string toShow = controller.WhatsAt(row.ToString(), column.ToString());
                    string btnName = $"btn{row}{column}";
                    Control[] btns = this.Controls.Find(btnName, true);
                    btns[0].Text = toShow;

                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int row = 0; row <=2; row++)
            {
                for (int column = 0; column <= 2; column++)
                {
                    Button newBtn = new Button();
                    newBtn.Name = $"btn{row}{column}";
                    newBtn.Location = new Point(100 * (column + 1), 100 * (row + 1));
                    newBtn.Size = new Size(100, 100);
                    newBtn.Text = "Z";
                    Controls.Add(newBtn);
                }
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(Color.FromArgb(255, 0, 0, 0));
            e.Graphics.DrawLine(pen, 90, 200, 410, 200);
            e.Graphics.DrawLine(pen, 90, 300, 410, 300);
            e.Graphics.DrawLine(pen, 200, 90, 200, 410);
            e.Graphics.DrawLine(pen, 300, 90, 300, 410);

        }
    }
}
