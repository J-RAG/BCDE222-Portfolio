﻿using System;

namespace NoughtsAndCrossesModel
{
    class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game();
            game.AddMark(0, 0, '0');
            System.Console.WriteLine($"turn {game.Turn()}");

            System.Console.ReadKey();

        }
    }
}
