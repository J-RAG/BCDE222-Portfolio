﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NoughtsAndCrossesModel
{
    public interface IGame
    {
        char WhatIsAt(int row, int column);
        void AddMark(int row, int column, char mark);
        int Turn();

    }
}
