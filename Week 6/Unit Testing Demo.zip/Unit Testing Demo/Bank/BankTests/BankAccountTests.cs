namespace BankTests
{
    [TestClass]
    public class BankAccountTests
    {
        [TestMethod]
        public void Debit_WithValidAmount_UpdatesBalance()
        {
            // arrange
            double beginningBalance = 11.99;
            double debitAmount = 4.55;
            double expected = 7.44;
            BankAccount bankAccount = new("Mr. Bryan Walton", beginningBalance);

            // act 
            bankAccount.Debit(debitAmount);
            double actual = bankAccount.Balance;

            // assert
            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }

        [TestMethod]
        public void Debit_WhenAmountisLessThanZero_ArgumentOutOfRangeExceptionShouldBeRaised()
        {
            // arrange
            double beginningBalance = 11.99;
            double debitAmount = -4.55;
            BankAccount bankAccount = new("Mr. Bryan Walton", beginningBalance);


            // assert
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => bankAccount.Debit(debitAmount));
        }

        [TestMethod]
        public void Credit_WhenAmountIsLessThanZero_ArgumentOutOfRangeExceptionShouldBeRaised()
        {
            // arrange
            double beginningBalance = 11.99;
            double creditAmount = -4.55;
            BankAccount bankAccount = new("Mr. Bryan Walton", beginningBalance);


            // assert
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => bankAccount.Credit(creditAmount));
        }
    }
}