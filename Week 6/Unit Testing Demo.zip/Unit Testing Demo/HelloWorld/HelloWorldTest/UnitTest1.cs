using System.Runtime.CompilerServices;

namespace HelloWorldTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            // Arrange 
            const string ExpectedResult = "Hello World!";

            // Act
            using var sw = new StringWriter();
            Console.SetOut(sw);
            HelloWorld.Program.Main();
            var result = sw.ToString().Trim();

            // Assert
            Assert.AreEqual(ExpectedResult, result);

        }
    }
}