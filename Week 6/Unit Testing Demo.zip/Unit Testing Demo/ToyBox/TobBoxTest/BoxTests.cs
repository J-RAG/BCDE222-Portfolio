﻿namespace ToyBoxTest
{
    [TestClass]
    public class BoxTests
    {
        [TestMethod]
        public void GetToyCount_WhenRunned_ReturnsToyCount()
        {
            int expectedCount = 3;

            Box box = new Box();
            box.AddToy("Mr. Clean", "Red", (decimal)2.50);
            box.AddToy("Mrs. Clean", "Green", (decimal)3.50);
            box.AddToy("Miss Clean", "Blue", (decimal)1.50);

            int resultCount = box.GetToyCount();

            Assert.AreEqual(expectedCount, resultCount);
        }
    }
}