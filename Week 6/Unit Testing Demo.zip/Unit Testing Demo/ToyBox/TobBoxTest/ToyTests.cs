namespace ToyBoxTest
{
    [TestClass]
    public class ToyTests
    {
        [TestMethod]
        public void GetName_WhenRan_ExpectsToReturnTheNameOfTheToy()
        {
            string expectedName = "Mr. Clean";
            Toy toy = new ("Mr. Clean", "Red", (decimal)2.50);

            string resultName = toy.GetName();

            Assert.AreEqual(expectedName, resultName);
        }
    }
}